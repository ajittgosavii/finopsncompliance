# ⚡ QUICKSTART - Deploy in 5 Minutes

## Prerequisites (2 minutes)

```bash
# 1. Install AWS CLI
pip install awscli

# 2. Configure AWS credentials
aws configure
# Enter: Access Key ID, Secret Access Key, Region (us-east-1), Output format (json)

# 3. Verify
aws sts get-caller-identity
```

## Deploy (3 minutes)

```bash
# Navigate to production deployment folder
cd production-deployment

# Make scripts executable
chmod +x scripts/*.sh

# Deploy everything with one command
./scripts/deploy.sh --email your-email@company.com
```

**That's it!** The script will:
1. ✅ Enable CloudTrail
2. ✅ Deploy AWS infrastructure
3. ✅ Configure Lambda function
4. ✅ Run test
5. ✅ Generate Streamlit config

## Test It

```bash
# Run test suite
./scripts/test.sh

# Check Lambda logs
aws logs tail /aws/lambda/threat-detection-handler --follow

# Query threats
aws dynamodb scan --table-name security-threats --max-items 5
```

## Update Streamlit App

1. **Replace the import** in your `streamlit_app.py`:

```python
# OLD
from ai_threat_scene_6_complete import render_ai_threat_analysis_scene

# NEW  
from ai_threat_scene_6_PRODUCTION import render_ai_threat_analysis_scene
```

2. **Copy the production file**:

```bash
cp streamlit/ai_threat_scene_6_PRODUCTION.py /path/to/your/streamlit/project/
```

3. **Install dependencies**:

```bash
pip install -r streamlit/requirements.txt
```

4. **Run Streamlit**:

```bash
streamlit run your_app.py
```

5. **Navigate to**: AI-Powered Remediation → Threat Analysis

## Verify It's Working

### Real-time Test

```bash
# Create a test IAM policy (will trigger detection)
aws iam put-role-policy \
    --role-name TestRole \
    --policy-name WildcardTest \
    --policy-document '{
        "Version": "2012-10-17",
        "Statement": [{
            "Effect": "Allow",
            "Action": "s3:*",
            "Resource": "*"
        }]
    }'
```

**Within 5 seconds:**
- ✅ Lambda detects the threat
- ✅ Claude AI analyzes it
- ✅ Threat stored in DynamoDB
- ✅ Email alert sent

**In Streamlit:**
- Navigate to AI-Powered Remediation → Threat Analysis
- See the red CRITICAL alert box
- Click "🤖 Analyze with AI"
- View AI analysis with 4 sections
- Click "🚀 Execute Remediation"

## What You Get

```
AWS ACCOUNT
    │
    ├─ CloudTrail ─────> Captures ALL API calls
    │
    ├─ EventBridge ────> Filters security events
    │
    ├─ Lambda ─────────> Detects threats + AI analysis
    │       │
    │       ├─> Bedrock (Claude AI)
    │       ├─> DynamoDB (stores threats)
    │       └─> SNS (sends alerts)
    │
    └─ Streamlit ──────> Displays real-time threats
```

## Troubleshooting

**No threats appearing?**
```bash
# Check if CloudTrail is working
aws cloudtrail get-trail-status --name security-monitoring-trail

# Check Lambda logs
aws logs tail /aws/lambda/threat-detection-handler --follow

# Verify EventBridge rules
aws events list-rules --name-prefix detect-
```

**Bedrock access denied?**
- Go to: https://console.aws.amazon.com/bedrock/home#/modelaccess
- Enable Claude 3.5 Sonnet model
- Wait 5 minutes for activation

**Streamlit not connecting?**
```bash
# Test AWS connectivity
python3 -c "import boto3; boto3.client('dynamodb').describe_table(TableName='security-threats')"

# Check secrets file
cat streamlit/.streamlit/secrets.toml
```

## Cleanup

To remove everything:

```bash
./scripts/rollback.sh
```

## Cost

**~$10-15/month** for:
- 1,000 threats detected/month
- Claude AI analysis
- DynamoDB storage
- CloudTrail logs

## Next Steps

1. **Week 1:** Monitor and tune detection rules
2. **Week 2:** Add custom threat patterns
3. **Week 3:** Enable auto-remediation
4. **Month 2:** Add compliance frameworks

## Support

- 📖 Full guide: `docs/PRODUCTION_DEPLOYMENT_GUIDE.md`
- 🏗️ Architecture: `docs/ARCHITECTURE_DIAGRAM.md`
- 🧪 Test: `./scripts/test.sh`
- 🔄 Rollback: `./scripts/rollback.sh`

---

**🎉 You're live! Start detecting real threats now.**
