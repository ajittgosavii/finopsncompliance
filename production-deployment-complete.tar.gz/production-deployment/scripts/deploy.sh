#!/bin/bash
# deploy.sh - Complete Production Deployment Script
# Usage: ./deploy.sh [options]

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
STACK_NAME="threat-detection-system"
AWS_REGION="us-east-1"
NOTIFICATION_EMAIL=""

# Function to print colored output
print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

# Function to check prerequisites
check_prerequisites() {
    print_info "Checking prerequisites..."
    
    # Check AWS CLI
    if ! command -v aws &> /dev/null; then
        print_error "AWS CLI not found. Please install: pip install awscli"
        exit 1
    fi
    print_success "AWS CLI found"
    
    # Check AWS credentials
    if ! aws sts get-caller-identity &> /dev/null; then
        print_error "AWS credentials not configured. Run: aws configure"
        exit 1
    fi
    print_success "AWS credentials configured"
    
    # Get AWS Account ID
    AWS_ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
    print_info "AWS Account ID: $AWS_ACCOUNT_ID"
    
    # Check Python
    if ! command -v python3 &> /dev/null; then
        print_error "Python 3 not found"
        exit 1
    fi
    print_success "Python 3 found"
}

# Function to enable CloudTrail
enable_cloudtrail() {
    print_info "Checking CloudTrail status..."
    
    # Check if trail exists
    TRAIL_NAME="security-monitoring-trail"
    
    if aws cloudtrail get-trail-status --name $TRAIL_NAME &> /dev/null; then
        print_success "CloudTrail already enabled: $TRAIL_NAME"
    else
        print_warning "CloudTrail not found. Creating trail..."
        
        # Create S3 bucket for CloudTrail
        BUCKET_NAME="cloudtrail-logs-${AWS_ACCOUNT_ID}"
        
        if ! aws s3 ls s3://$BUCKET_NAME &> /dev/null; then
            print_info "Creating S3 bucket: $BUCKET_NAME"
            aws s3 mb s3://$BUCKET_NAME --region $AWS_REGION
            
            # Set bucket policy
            cat > /tmp/bucket-policy.json <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "AWSCloudTrailAclCheck",
      "Effect": "Allow",
      "Principal": {
        "Service": "cloudtrail.amazonaws.com"
      },
      "Action": "s3:GetBucketAcl",
      "Resource": "arn:aws:s3:::$BUCKET_NAME"
    },
    {
      "Sid": "AWSCloudTrailWrite",
      "Effect": "Allow",
      "Principal": {
        "Service": "cloudtrail.amazonaws.com"
      },
      "Action": "s3:PutObject",
      "Resource": "arn:aws:s3:::$BUCKET_NAME/AWSLogs/${AWS_ACCOUNT_ID}/*",
      "Condition": {
        "StringEquals": {
          "s3:x-amz-acl": "bucket-owner-full-control"
        }
      }
    }
  ]
}
EOF
            aws s3api put-bucket-policy --bucket $BUCKET_NAME --policy file:///tmp/bucket-policy.json
        fi
        
        # Create trail
        aws cloudtrail create-trail \
            --name $TRAIL_NAME \
            --s3-bucket-name $BUCKET_NAME \
            --is-multi-region-trail \
            --enable-log-file-validation
        
        # Start logging
        aws cloudtrail start-logging --name $TRAIL_NAME
        
        print_success "CloudTrail enabled"
    fi
}

# Function to check Bedrock access
check_bedrock() {
    print_info "Checking AWS Bedrock (Claude) access..."
    
    # Check if Claude model is available
    if aws bedrock list-foundation-models --region $AWS_REGION --query 'modelSummaries[?modelId==`anthropic.claude-3-5-sonnet-20241022-v2:0`]' --output text &> /dev/null; then
        print_success "Bedrock Claude model accessible"
    else
        print_warning "Bedrock Claude model not accessible"
        print_info "Please enable model access at: https://console.aws.amazon.com/bedrock/home#/modelaccess"
        read -p "Press Enter after enabling Bedrock access..."
    fi
}

# Function to deploy CloudFormation stack
deploy_stack() {
    print_info "Deploying CloudFormation stack: $STACK_NAME"
    
    # Get notification email
    if [ -z "$NOTIFICATION_EMAIL" ]; then
        read -p "Enter email for security alerts: " NOTIFICATION_EMAIL
    fi
    
    # Deploy stack
    aws cloudformation create-stack \
        --stack-name $STACK_NAME \
        --template-body file://cloudformation/cloudformation_threat_detection.yaml \
        --parameters ParameterKey=NotificationEmail,ParameterValue=$NOTIFICATION_EMAIL \
        --capabilities CAPABILITY_NAMED_IAM \
        --region $AWS_REGION
    
    print_info "Waiting for stack creation (this may take 3-5 minutes)..."
    
    aws cloudformation wait stack-create-complete \
        --stack-name $STACK_NAME \
        --region $AWS_REGION
    
    print_success "CloudFormation stack deployed successfully"
    
    # Get outputs
    print_info "Stack Outputs:"
    aws cloudformation describe-stacks \
        --stack-name $STACK_NAME \
        --region $AWS_REGION \
        --query 'Stacks[0].Outputs' \
        --output table
}

# Function to deploy Lambda code
deploy_lambda() {
    print_info "Deploying Lambda function code..."
    
    # Create Lambda deployment package
    cd lambda
    zip -q threat_detection_lambda.zip threat_detection_lambda.py
    
    # Upload to Lambda
    aws lambda update-function-code \
        --function-name threat-detection-handler \
        --zip-file fileb://threat_detection_lambda.zip \
        --region $AWS_REGION
    
    # Wait for update to complete
    aws lambda wait function-updated \
        --function-name threat-detection-handler \
        --region $AWS_REGION
    
    print_success "Lambda function deployed"
    
    cd ..
}

# Function to test the system
test_system() {
    print_info "Testing threat detection system..."
    
    # Create a test role
    TEST_ROLE_NAME="ThreatDetectionTestRole"
    
    print_info "Creating test IAM role (will trigger detection)..."
    
    # Create trust policy
    cat > /tmp/trust-policy.json <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Service": "lambda.amazonaws.com"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
EOF
    
    # Create role
    if aws iam create-role \
        --role-name $TEST_ROLE_NAME \
        --assume-role-policy-document file:///tmp/trust-policy.json &> /dev/null; then
        
        print_info "Adding test policy (WILL TRIGGER ALERT)..."
        
        # Add a wildcard policy (should trigger detection)
        aws iam put-role-policy \
            --role-name $TEST_ROLE_NAME \
            --policy-name TestWildcardPolicy \
            --policy-document '{
                "Version": "2012-10-17",
                "Statement": [{
                    "Effect": "Allow",
                    "Action": "s3:*",
                    "Resource": "*"
                }]
            }'
        
        print_success "Test policy added - this should trigger threat detection!"
        print_info "Check Lambda logs in 5-10 seconds:"
        print_info "aws logs tail /aws/lambda/threat-detection-handler --follow"
        
        # Cleanup
        sleep 2
        print_info "Cleaning up test role..."
        aws iam delete-role-policy --role-name $TEST_ROLE_NAME --policy-name TestWildcardPolicy
        aws iam delete-role --role-name $TEST_ROLE_NAME
        
        print_success "Test complete - check your email for alert!"
    else
        print_warning "Test role already exists or couldn't be created"
    fi
}

# Function to verify deployment
verify_deployment() {
    print_info "Verifying deployment..."
    
    # Check DynamoDB table
    if aws dynamodb describe-table --table-name security-threats --region $AWS_REGION &> /dev/null; then
        print_success "DynamoDB table exists"
    else
        print_error "DynamoDB table not found"
    fi
    
    # Check Lambda function
    if aws lambda get-function --function-name threat-detection-handler --region $AWS_REGION &> /dev/null; then
        print_success "Lambda function exists"
    else
        print_error "Lambda function not found"
    fi
    
    # Check EventBridge rules
    RULE_COUNT=$(aws events list-rules --region $AWS_REGION --query 'Rules[?starts_with(Name, `detect-`)].Name' --output text | wc -w)
    if [ $RULE_COUNT -ge 3 ]; then
        print_success "EventBridge rules configured ($RULE_COUNT rules)"
    else
        print_warning "EventBridge rules may not be complete"
    fi
}

# Function to get connection details
get_connection_details() {
    print_info "Getting connection details for Streamlit app..."
    
    # Get DynamoDB table name
    TABLE_NAME=$(aws cloudformation describe-stacks \
        --stack-name $STACK_NAME \
        --region $AWS_REGION \
        --query 'Stacks[0].Outputs[?OutputKey==`ThreatsTableName`].OutputValue' \
        --output text)
    
    # Get SNS topic ARN
    SNS_TOPIC=$(aws cloudformation describe-stacks \
        --stack-name $STACK_NAME \
        --region $AWS_REGION \
        --query 'Stacks[0].Outputs[?OutputKey==`SNSTopicArn`].OutputValue' \
        --output text)
    
    # Create secrets.toml for Streamlit
    cat > streamlit/.streamlit/secrets.toml <<EOF
[aws]
region = "$AWS_REGION"
threats_table = "$TABLE_NAME"
sns_topic_arn = "$SNS_TOPIC"

# For local development, add credentials here
# For production, use IAM roles instead
# [default]
# aws_access_key_id = "YOUR_KEY"
# aws_secret_access_key = "YOUR_SECRET"
EOF
    
    print_success "Created Streamlit secrets file"
    print_info "File: streamlit/.streamlit/secrets.toml"
    
    echo ""
    print_info "Next steps for Streamlit app:"
    echo "1. cd streamlit"
    echo "2. pip install -r requirements.txt"
    echo "3. streamlit run your_main_app.py"
    echo "4. Update your app to import: from ai_threat_scene_6_PRODUCTION import render_ai_threat_analysis_scene"
}

# Function to show summary
show_summary() {
    echo ""
    echo "════════════════════════════════════════════════════════"
    print_success "DEPLOYMENT COMPLETE!"
    echo "════════════════════════════════════════════════════════"
    echo ""
    print_info "What was deployed:"
    echo "  ✅ CloudTrail for event capture"
    echo "  ✅ EventBridge rules for event filtering"
    echo "  ✅ Lambda function for threat detection"
    echo "  ✅ DynamoDB table for threat storage"
    echo "  ✅ SNS topic for alerts"
    echo "  ✅ IAM roles with least-privilege permissions"
    echo ""
    print_info "Important URLs:"
    echo "  📊 CloudWatch Logs: https://console.aws.amazon.com/cloudwatch/home?region=$AWS_REGION#logsV2:log-groups/log-group/\$252Faws\$252Flambda\$252Fthreat-detection-handler"
    echo "  📧 SNS Subscriptions: https://console.aws.amazon.com/sns/v3/home?region=$AWS_REGION#/topics"
    echo "  🗃️  DynamoDB Table: https://console.aws.amazon.com/dynamodbv2/home?region=$AWS_REGION#table?name=security-threats"
    echo ""
    print_info "Next steps:"
    echo "  1. Confirm SNS email subscription (check your inbox)"
    echo "  2. Update your Streamlit app with production code"
    echo "  3. Monitor Lambda logs for events"
    echo "  4. Test by making IAM changes"
    echo ""
    print_warning "Estimated monthly cost: \$10-15 USD (based on 1000 threats/month)"
    echo ""
}

# Main execution
main() {
    echo "════════════════════════════════════════════════════════"
    echo "🚀 AWS Threat Detection System - Production Deployment"
    echo "════════════════════════════════════════════════════════"
    echo ""
    
    # Parse arguments
    while [[ $# -gt 0 ]]; do
        case $1 in
            --email)
                NOTIFICATION_EMAIL="$2"
                shift 2
                ;;
            --region)
                AWS_REGION="$2"
                shift 2
                ;;
            --skip-test)
                SKIP_TEST=true
                shift
                ;;
            *)
                print_error "Unknown option: $1"
                exit 1
                ;;
        esac
    done
    
    # Execute deployment steps
    check_prerequisites
    enable_cloudtrail
    check_bedrock
    deploy_stack
    deploy_lambda
    verify_deployment
    
    if [ "$SKIP_TEST" != "true" ]; then
        test_system
    fi
    
    get_connection_details
    show_summary
}

# Run main function
main "$@"
