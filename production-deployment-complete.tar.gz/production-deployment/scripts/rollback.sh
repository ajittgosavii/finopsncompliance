#!/bin/bash
# rollback.sh - Rollback/Cleanup Script
# Usage: ./rollback.sh

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

STACK_NAME="threat-detection-system"
AWS_REGION="us-east-1"

print_info() {
    echo -e "${YELLOW}ℹ️  $1${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

echo "════════════════════════════════════════════════════════"
echo "🔄 Threat Detection System - Rollback/Cleanup"
echo "════════════════════════════════════════════════════════"
echo ""

print_error "WARNING: This will delete all threat detection resources!"
read -p "Are you sure you want to continue? (yes/no): " CONFIRM

if [ "$CONFIRM" != "yes" ]; then
    print_info "Rollback cancelled"
    exit 0
fi

print_info "Starting rollback..."

# Delete CloudFormation stack
print_info "Deleting CloudFormation stack..."
if aws cloudformation delete-stack --stack-name $STACK_NAME --region $AWS_REGION 2>/dev/null; then
    print_info "Waiting for stack deletion..."
    aws cloudformation wait stack-delete-complete --stack-name $STACK_NAME --region $AWS_REGION || true
    print_success "CloudFormation stack deleted"
else
    print_info "Stack not found or already deleted"
fi

# Clean up CloudTrail (optional)
read -p "Delete CloudTrail trail? (yes/no): " DELETE_TRAIL

if [ "$DELETE_TRAIL" == "yes" ]; then
    TRAIL_NAME="security-monitoring-trail"
    
    if aws cloudtrail stop-logging --name $TRAIL_NAME --region $AWS_REGION 2>/dev/null; then
        aws cloudtrail delete-trail --name $TRAIL_NAME --region $AWS_REGION
        print_success "CloudTrail deleted"
    else
        print_info "CloudTrail not found"
    fi
    
    # Delete S3 bucket
    AWS_ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
    BUCKET_NAME="cloudtrail-logs-${AWS_ACCOUNT_ID}"
    
    if aws s3 ls s3://$BUCKET_NAME 2>/dev/null; then
        print_info "Emptying S3 bucket..."
        aws s3 rm s3://$BUCKET_NAME --recursive
        aws s3 rb s3://$BUCKET_NAME
        print_success "S3 bucket deleted"
    fi
fi

print_success "Rollback complete!"
