#!/bin/bash
# test.sh - Test Threat Detection System
# Usage: ./test.sh

set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

AWS_REGION="us-east-1"

print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_test() {
    echo -e "${YELLOW}🧪 TEST: $1${NC}"
}

echo "════════════════════════════════════════════════════════"
echo "🧪 Threat Detection System - Testing Suite"
echo "════════════════════════════════════════════════════════"
echo ""

# Test 1: IAM Policy Change
print_test "Creating test IAM policy change (should trigger CRITICAL alert)"

TEST_ROLE="ThreatDetectionTest-$(date +%s)"

# Create role
aws iam create-role \
    --role-name $TEST_ROLE \
    --assume-role-policy-document '{
        "Version": "2012-10-17",
        "Statement": [{
            "Effect": "Allow",
            "Principal": {"Service": "lambda.amazonaws.com"},
            "Action": "sts:AssumeRole"
        }]
    }' > /dev/null

print_info "Created test role: $TEST_ROLE"

# Add wildcard policy (CRITICAL threat)
aws iam put-role-policy \
    --role-name $TEST_ROLE \
    --policy-name WildcardPolicy \
    --policy-document '{
        "Version": "2012-10-17",
        "Statement": [{
            "Effect": "Allow",
            "Action": "s3:*",
            "Resource": "*"
        }]
    }'

print_success "Test 1: Wildcard policy added (should trigger CRITICAL alert)"

sleep 3

# Cleanup Test 1
print_info "Cleaning up test role..."
aws iam delete-role-policy --role-name $TEST_ROLE --policy-name WildcardPolicy
aws iam delete-role --role-name $TEST_ROLE

# Test 2: After-hours activity detection
CURRENT_HOUR=$(date -u +%H)
print_test "Current UTC hour: $CURRENT_HOUR"

if [ $CURRENT_HOUR -lt 6 ] || [ $CURRENT_HOUR -gt 22 ]; then
    print_info "Test 2: After-hours flag WILL be triggered (current time is off-hours)"
else
    print_info "Test 2: After-hours flag will NOT be triggered (current time is business hours)"
fi

# Test 3: Check Lambda execution
print_test "Checking Lambda execution logs..."

sleep 5

LATEST_LOGS=$(aws logs tail /aws/lambda/threat-detection-handler --since 2m --format short 2>/dev/null | head -20)

if echo "$LATEST_LOGS" | grep -q "Threat detected"; then
    print_success "Test 3: Lambda detected the threat!"
    echo "$LATEST_LOGS"
else
    print_info "Test 3: Waiting for Lambda to process... (check logs in 30 seconds)"
fi

# Test 4: Check DynamoDB
print_test "Checking DynamoDB for stored threats..."

THREAT_COUNT=$(aws dynamodb scan --table-name security-threats --select COUNT --region $AWS_REGION --output text --query 'Count' 2>/dev/null || echo "0")

print_success "Test 4: Found $THREAT_COUNT total threats in database"

if [ "$THREAT_COUNT" -gt 0 ]; then
    print_info "Latest threat:"
    aws dynamodb query \
        --table-name security-threats \
        --index-name status-timestamp-index \
        --key-condition-expression "#st = :status" \
        --expression-attribute-names '{"#st":"status"}' \
        --expression-attribute-values '{":status":{"S":"ACTIVE"}}' \
        --limit 1 \
        --scan-index-forward false \
        --region $AWS_REGION \
        --output table \
        --query 'Items[0].{ThreatID:threat_id.S,Severity:severity.S,Event:event_name.S,Time:timestamp.S}' 2>/dev/null || print_info "No active threats"
fi

# Test 5: SNS Alert
print_test "Check your email for SNS alert"
print_info "You should receive an email with subject: 🚨 CRITICAL Security Threat: PutRolePolicy"

echo ""
print_success "Testing complete!"
echo ""
print_info "To view all threats in Streamlit:"
echo "  1. cd streamlit"
echo "  2. streamlit run your_app.py"
echo "  3. Navigate to: AI-Powered Remediation → Threat Analysis"
echo ""
print_info "To view Lambda logs in real-time:"
echo "  aws logs tail /aws/lambda/threat-detection-handler --follow"
echo ""
