"""
AWS Lambda Function: Real-Time Threat Detection
Triggered by: EventBridge (CloudTrail events)
Purpose: Detect unauthorized IAM policy changes and security threats

Deploy this function to AWS Lambda with appropriate IAM permissions
"""

import json
import boto3
import os
from datetime import datetime, timezone
from typing import Dict, Any, List

# AWS Clients
dynamodb = boto3.resource('dynamodb')
sns = boto3.client('sns')
bedrock = boto3.client('bedrock-runtime')

# Environment Variables
THREATS_TABLE = os.environ.get('THREATS_TABLE', 'security-threats')
SNS_TOPIC_ARN = os.environ.get('SNS_TOPIC_ARN')

# DynamoDB Table
threats_table = dynamodb.Table(THREATS_TABLE)


def lambda_handler(event, context):
    """
    Main Lambda handler for threat detection
    Triggered by EventBridge when CloudTrail captures IAM events
    """
    
    print(f"Received event: {json.dumps(event)}")
    
    try:
        # Extract CloudTrail event details
        detail = event.get('detail', {})
        event_name = detail.get('eventName')
        event_source = detail.get('eventSource')
        event_time = detail.get('eventTime')
        user_identity = detail.get('userIdentity', {})
        request_parameters = detail.get('requestParameters', {})
        source_ip = detail.get('sourceIPAddress')
        user_agent = detail.get('userAgent')
        account_id = detail.get('recipientAccountId')
        
        # Analyze the threat
        threat_analysis = analyze_threat(
            event_name=event_name,
            event_source=event_source,
            user_identity=user_identity,
            request_parameters=request_parameters,
            source_ip=source_ip,
            event_time=event_time,
            account_id=account_id
        )
        
        if threat_analysis['is_threat']:
            # Store threat in DynamoDB
            threat_id = store_threat(
                event_details=detail,
                threat_analysis=threat_analysis,
                event_time=event_time,
                account_id=account_id
            )
            
            # Get AI analysis from Claude
            ai_analysis = get_ai_analysis(detail, threat_analysis)
            
            # Update threat with AI analysis
            update_threat_with_ai(threat_id, ai_analysis)
            
            # Send alert
            send_alert(threat_id, threat_analysis, ai_analysis)
            
            print(f"Threat detected and stored: {threat_id}")
            
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'threat_detected': True,
                    'threat_id': threat_id,
                    'severity': threat_analysis['severity']
                })
            }
        else:
            print(f"No threat detected for event: {event_name}")
            return {
                'statusCode': 200,
                'body': json.dumps({'threat_detected': False})
            }
            
    except Exception as e:
        print(f"Error processing event: {str(e)}")
        raise


def analyze_threat(event_name: str, event_source: str, user_identity: Dict,
                   request_parameters: Dict, source_ip: str, event_time: str,
                   account_id: str) -> Dict[str, Any]:
    """
    Analyze if the event represents a security threat
    
    Returns:
        Dict with threat analysis results
    """
    
    threat_indicators = []
    severity = 'LOW'
    is_threat = False
    
    # Get user info
    user_arn = user_identity.get('arn', '')
    principal_id = user_identity.get('principalId', '')
    user_type = user_identity.get('type', '')
    
    # Check 1: High-risk IAM actions
    high_risk_actions = [
        'PutRolePolicy',
        'PutUserPolicy',
        'AttachRolePolicy',
        'AttachUserPolicy',
        'CreateAccessKey',
        'CreateUser',
        'DeleteTrail',
        'StopLogging',
        'PutBucketPolicy',
        'PutBucketPublicAccessBlock'
    ]
    
    if event_name in high_risk_actions:
        threat_indicators.append({
            'type': 'HIGH_RISK_ACTION',
            'description': f'High-risk action detected: {event_name}'
        })
        severity = 'HIGH'
        is_threat = True
    
    # Check 2: Root account usage
    if user_type == 'Root':
        threat_indicators.append({
            'type': 'ROOT_ACCOUNT_USAGE',
            'description': 'Root account used for action'
        })
        severity = 'CRITICAL'
        is_threat = True
    
    # Check 3: Unusual time (after hours)
    event_hour = datetime.fromisoformat(event_time.replace('Z', '+00:00')).hour
    if event_hour < 6 or event_hour > 22:  # Outside 6 AM - 10 PM
        threat_indicators.append({
            'type': 'AFTER_HOURS_ACTIVITY',
            'description': f'Activity detected at unusual time: {event_hour}:00 UTC'
        })
        if severity == 'LOW':
            severity = 'MEDIUM'
        is_threat = True
    
    # Check 4: Suspicious policy content
    if event_name in ['PutRolePolicy', 'PutUserPolicy']:
        policy_doc = request_parameters.get('policyDocument', '')
        if isinstance(policy_doc, str):
            policy_doc = json.loads(policy_doc)
        
        # Check for wildcard permissions
        if check_wildcard_permissions(policy_doc):
            threat_indicators.append({
                'type': 'WILDCARD_PERMISSIONS',
                'description': 'Policy grants wildcard (*) permissions'
            })
            severity = 'CRITICAL'
            is_threat = True
    
    # Check 5: Privilege escalation
    if event_name in ['AttachRolePolicy', 'PutRolePolicy']:
        role_name = request_parameters.get('roleName', '')
        if 'admin' in role_name.lower() or 'privileged' in role_name.lower():
            threat_indicators.append({
                'type': 'PRIVILEGE_ESCALATION',
                'description': f'Modification to privileged role: {role_name}'
            })
            severity = 'CRITICAL'
            is_threat = True
    
    # Check 6: Compliance-sensitive resources
    if check_compliance_sensitive(request_parameters, account_id):
        threat_indicators.append({
            'type': 'COMPLIANCE_IMPACT',
            'description': 'Change affects compliance-regulated resources'
        })
        if severity in ['LOW', 'MEDIUM']:
            severity = 'HIGH'
        is_threat = True
    
    return {
        'is_threat': is_threat,
        'severity': severity,
        'threat_indicators': threat_indicators,
        'event_name': event_name,
        'user_arn': user_arn,
        'principal_id': principal_id,
        'source_ip': source_ip
    }


def check_wildcard_permissions(policy_doc: Dict) -> bool:
    """Check if policy contains wildcard permissions"""
    try:
        statements = policy_doc.get('Statement', [])
        for statement in statements:
            if statement.get('Effect') == 'Allow':
                actions = statement.get('Action', [])
                if isinstance(actions, str):
                    actions = [actions]
                
                # Check for wildcards
                if '*' in actions or any('*' in action for action in actions):
                    resources = statement.get('Resource', [])
                    if isinstance(resources, str):
                        resources = [resources]
                    if '*' in resources or any('*' in res for res in resources):
                        return True
        return False
    except:
        return False


def check_compliance_sensitive(request_parameters: Dict, account_id: str) -> bool:
    """Check if the change affects compliance-sensitive resources"""
    # Check for PHI/PII related resources (healthcare, financial data)
    sensitive_keywords = [
        'healthcare', 'health', 'phi', 'hipaa',
        'pci', 'payment', 'financial', 'gdpr',
        'pii', 'personal', 'customer-data'
    ]
    
    # Check role/policy names
    role_name = request_parameters.get('roleName', '').lower()
    policy_name = request_parameters.get('policyName', '').lower()
    
    for keyword in sensitive_keywords:
        if keyword in role_name or keyword in policy_name:
            return True
    
    return False


def get_ai_analysis(event_details: Dict, threat_analysis: Dict) -> Dict[str, Any]:
    """
    Get AI analysis from Claude via AWS Bedrock
    
    Returns:
        Dict with AI analysis results
    """
    
    try:
        # Prepare prompt for Claude
        prompt = f"""Analyze this AWS security event and provide a comprehensive threat assessment.

Event Details:
{json.dumps(event_details, indent=2)}

Automated Threat Analysis:
{json.dumps(threat_analysis, indent=2)}

Please provide:
1. Threat Assessment - Risk level and potential impact
2. Compliance Impact - Which compliance frameworks are affected (HIPAA, PCI-DSS, SOC 2, GDPR)
3. Pattern Detection - Any anomalies or insider threat indicators
4. Recommended Actions - Specific steps to remediate (prioritized)

Format your response as JSON with these keys:
{{
  "threat_assessment": "...",
  "compliance_impact": ["framework1", "framework2"],
  "compliance_details": "...",
  "pattern_detection": "...",
  "recommended_actions": [
    {{"priority": "IMMEDIATE", "action": "..."}},
    {{"priority": "HIGH", "action": "..."}},
    {{"priority": "INVESTIGATE", "action": "..."}},
    {{"priority": "PREVENT", "action": "..."}}
  ],
  "risk_score": 85,
  "business_impact": "..."
}}
"""
        
        # Call Claude via Bedrock
        response = bedrock.invoke_model(
            modelId='anthropic.claude-3-5-sonnet-20241022-v2:0',
            body=json.dumps({
                'anthropic_version': 'bedrock-2023-05-31',
                'max_tokens': 2000,
                'messages': [
                    {
                        'role': 'user',
                        'content': prompt
                    }
                ]
            })
        )
        
        # Parse response
        response_body = json.loads(response['body'].read())
        ai_response = response_body['content'][0]['text']
        
        # Extract JSON from response
        import re
        json_match = re.search(r'\{.*\}', ai_response, re.DOTALL)
        if json_match:
            ai_analysis = json.loads(json_match.group())
        else:
            ai_analysis = {'raw_response': ai_response}
        
        return ai_analysis
        
    except Exception as e:
        print(f"Error getting AI analysis: {str(e)}")
        return {
            'threat_assessment': 'AI analysis unavailable',
            'error': str(e)
        }


def store_threat(event_details: Dict, threat_analysis: Dict, 
                 event_time: str, account_id: str) -> str:
    """
    Store threat in DynamoDB
    
    Returns:
        threat_id (str)
    """
    
    threat_id = f"THREAT-{account_id}-{int(datetime.now().timestamp() * 1000)}"
    
    # Extract key information
    user_identity = event_details.get('userIdentity', {})
    request_parameters = event_details.get('requestParameters', {})
    
    item = {
        'threat_id': threat_id,
        'timestamp': event_time,
        'account_id': account_id,
        'severity': threat_analysis['severity'],
        'event_name': threat_analysis['event_name'],
        'user_arn': threat_analysis.get('user_arn', ''),
        'principal_id': threat_analysis.get('principal_id', ''),
        'source_ip': threat_analysis.get('source_ip', ''),
        'threat_indicators': threat_analysis['threat_indicators'],
        'resource_affected': extract_resource_info(request_parameters),
        'status': 'ACTIVE',
        'created_at': datetime.now(timezone.utc).isoformat(),
        'event_details': event_details,
        'remediation_status': 'PENDING'
    }
    
    threats_table.put_item(Item=item)
    
    return threat_id


def extract_resource_info(request_parameters: Dict) -> str:
    """Extract human-readable resource information"""
    
    if 'roleName' in request_parameters:
        if 'policyName' in request_parameters:
            return f"IAM Policy '{request_parameters['policyName']}' on Role '{request_parameters['roleName']}'"
        return f"IAM Role '{request_parameters['roleName']}'"
    
    if 'userName' in request_parameters:
        return f"IAM User '{request_parameters['userName']}'"
    
    if 'bucketName' in request_parameters:
        return f"S3 Bucket '{request_parameters['bucketName']}'"
    
    return "Unknown resource"


def update_threat_with_ai(threat_id: str, ai_analysis: Dict):
    """Update threat record with AI analysis"""
    
    try:
        threats_table.update_item(
            Key={'threat_id': threat_id},
            UpdateExpression='SET ai_analysis = :ai, updated_at = :updated',
            ExpressionAttributeValues={
                ':ai': ai_analysis,
                ':updated': datetime.now(timezone.utc).isoformat()
            }
        )
    except Exception as e:
        print(f"Error updating threat with AI analysis: {str(e)}")


def send_alert(threat_id: str, threat_analysis: Dict, ai_analysis: Dict):
    """Send alert via SNS"""
    
    if not SNS_TOPIC_ARN:
        print("SNS_TOPIC_ARN not configured, skipping alert")
        return
    
    try:
        severity = threat_analysis['severity']
        event_name = threat_analysis['event_name']
        
        message = f"""
🚨 SECURITY THREAT DETECTED

Threat ID: {threat_id}
Severity: {severity}
Event: {event_name}
Time: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}

Threat Indicators:
{json.dumps(threat_analysis['threat_indicators'], indent=2)}

AI Assessment:
{ai_analysis.get('threat_assessment', 'Analyzing...')}

Recommended Actions:
{json.dumps(ai_analysis.get('recommended_actions', []), indent=2)}

View full details in Cloud Compliance Canvas dashboard.
        """
        
        sns.publish(
            TopicArn=SNS_TOPIC_ARN,
            Subject=f'🚨 {severity} Security Threat: {event_name}',
            Message=message
        )
        
        print(f"Alert sent for threat {threat_id}")
        
    except Exception as e:
        print(f"Error sending alert: {str(e)}")


# Additional helper functions for production

def get_user_context(user_arn: str) -> Dict:
    """Get additional context about the user from IAM"""
    try:
        iam = boto3.client('iam')
        
        # Extract user name from ARN
        user_name = user_arn.split('/')[-1]
        
        # Get user details
        user_info = iam.get_user(UserName=user_name)
        
        # Get user tags
        tags = iam.list_user_tags(UserName=user_name)
        
        return {
            'user_name': user_name,
            'create_date': user_info['User']['CreateDate'].isoformat(),
            'tags': {tag['Key']: tag['Value'] for tag in tags['Tags']}
        }
    except:
        return {}


def check_rate_limit(principal_id: str, time_window_minutes: int = 120) -> Dict:
    """Check if user has exceeded normal API call rate"""
    try:
        # Query threats table for recent activity by this user
        from datetime import timedelta
        
        cutoff_time = (datetime.now(timezone.utc) - timedelta(minutes=time_window_minutes)).isoformat()
        
        response = threats_table.query(
            IndexName='principal_id-timestamp-index',  # You'll need to create this GSI
            KeyConditionExpression='principal_id = :pid AND #ts > :cutoff',
            ExpressionAttributeNames={'#ts': 'timestamp'},
            ExpressionAttributeValues={
                ':pid': principal_id,
                ':cutoff': cutoff_time
            }
        )
        
        event_count = response['Count']
        
        # Normal threshold: 10 events per 2 hours
        is_anomalous = event_count > 10
        
        return {
            'event_count': event_count,
            'time_window_minutes': time_window_minutes,
            'is_anomalous': is_anomalous,
            'threshold': 10
        }
    except:
        return {'event_count': 0, 'is_anomalous': False}
