# 📁 File Structure Explained

## What Each File Does

```
production-deployment/
│
├── 📖 README.md                          ← START HERE - Complete overview
├── ⚡ QUICKSTART.md                     ← 5-minute deployment guide
│
├── cloudformation/                       ← AWS Infrastructure
│   └── cloudformation_threat_detection.yaml
│       Purpose: Defines all AWS resources
│       Creates: DynamoDB, Lambda, EventBridge, SNS, IAM roles
│       Deploy: One CloudFormation stack = entire system
│
├── lambda/                               ← Threat Detection Engine
│   ├── threat_detection_lambda.py
│   │   Purpose: Main detection logic
│   │   Triggers: EventBridge (on IAM/S3 changes)
│   │   Does: Analyzes threats, calls Claude AI, stores in DynamoDB
│   │   Runtime: Python 3.11, ~500ms execution
│   │
│   └── requirements.txt
│       Purpose: Lambda dependencies (boto3 already included)
│
├── streamlit/                            ← User Interface
│   ├── ai_threat_scene_6_PRODUCTION.py
│   │   Purpose: Production UI with real AWS integration
│   │   Replaces: ai_threat_scene_6_complete.py (demo version)
│   │   Reads: DynamoDB for real threats
│   │   Features: Real-time alerts, AI analysis, auto-remediation
│   │
│   └── requirements.txt
│       Purpose: Streamlit app dependencies
│       Install: pip install -r requirements.txt
│
├── scripts/                              ← Automation Scripts
│   ├── 🚀 deploy.sh                     ← ONE-CLICK DEPLOYMENT
│   │   Purpose: Automated end-to-end deployment
│   │   Usage: ./deploy.sh --email your@email.com
│   │   Does:
│   │     1. Check prerequisites
│   │     2. Enable CloudTrail
│   │     3. Deploy CloudFormation
│   │     4. Upload Lambda code
│   │     5. Run tests
│   │     6. Generate Streamlit config
│   │   Time: ~5 minutes
│   │
│   ├── 🧪 test.sh                       ← Testing Suite
│   │   Purpose: Verify deployment works
│   │   Usage: ./test.sh
│   │   Does:
│   │     1. Creates test IAM policy
│   │     2. Verifies Lambda detection
│   │     3. Checks DynamoDB storage
│   │     4. Confirms SNS alerts
│   │   Time: ~30 seconds
│   │
│   └── 🔄 rollback.sh                   ← Cleanup Script
│       Purpose: Remove all resources
│       Usage: ./rollback.sh
│       Does: Deletes CloudFormation stack + optional CloudTrail
│       Time: ~3 minutes
│
└── docs/                                 ← Documentation
    ├── PRODUCTION_DEPLOYMENT_GUIDE.md
    │   Purpose: Comprehensive deployment guide
    │   Content: Step-by-step instructions, troubleshooting, costs
    │   When: Reference for detailed deployment
    │
    └── ARCHITECTURE_DIAGRAM.md
        Purpose: System architecture explained
        Content: Data flow, services, timelines, security
        When: Understanding how it works
```

---

## 🎯 Which Files to Use When

### Scenario 1: First-Time Deployment

**Goal:** Get system running as fast as possible

**Files to use:**
1. Read: `QUICKSTART.md`
2. Run: `scripts/deploy.sh`
3. Update: Your `streamlit_app.py` import

**Time:** 5 minutes

---

### Scenario 2: Understanding the System

**Goal:** Learn how everything works

**Files to read:**
1. `README.md` - Overview
2. `docs/ARCHITECTURE_DIAGRAM.md` - Architecture
3. `docs/PRODUCTION_DEPLOYMENT_GUIDE.md` - Detailed guide

**Time:** 30 minutes

---

### Scenario 3: Manual Deployment

**Goal:** Deploy step-by-step (not automated)

**Files to use:**
1. Read: `docs/PRODUCTION_DEPLOYMENT_GUIDE.md`
2. Deploy: `cloudformation/cloudformation_threat_detection.yaml`
3. Upload: `lambda/threat_detection_lambda.py`
4. Update: `streamlit/ai_threat_scene_6_PRODUCTION.py`

**Time:** 15 minutes

---

### Scenario 4: Testing After Deployment

**Goal:** Verify everything works

**Files to use:**
1. Run: `scripts/test.sh`
2. Check: Lambda logs, DynamoDB, Email

**Time:** 2 minutes

---

### Scenario 5: Customization

**Goal:** Modify detection rules or add features

**Files to edit:**
- `lambda/threat_detection_lambda.py` - Detection logic
- `cloudformation/cloudformation_threat_detection.yaml` - EventBridge rules
- `streamlit/ai_threat_scene_6_PRODUCTION.py` - UI customization

---

### Scenario 6: Cleanup/Rollback

**Goal:** Remove all resources

**Files to use:**
1. Run: `scripts/rollback.sh`

**Time:** 3 minutes

---

## 🔄 Data Flow Between Files

```
┌─────────────────────────────────────────────────────────┐
│ 1. CloudFormation Stack                                 │
│    cloudformation/cloudformation_threat_detection.yaml  │
│                                                          │
│    Creates:                                             │
│    • DynamoDB table                                     │
│    • Lambda function (placeholder)                      │
│    • EventBridge rules                                  │
│    • SNS topic                                          │
│    • IAM roles                                          │
└──────────────────────┬──────────────────────────────────┘
                       │
                       │ Resources created
                       ▼
┌─────────────────────────────────────────────────────────┐
│ 2. Lambda Function Code                                 │
│    lambda/threat_detection_lambda.py                    │
│                                                          │
│    Uploaded to: threat-detection-handler                │
│    Triggered by: EventBridge rules                      │
│    Writes to: DynamoDB table                            │
│    Uses: Bedrock (Claude AI)                            │
└──────────────────────┬──────────────────────────────────┘
                       │
                       │ Threats stored in DynamoDB
                       ▼
┌─────────────────────────────────────────────────────────┐
│ 3. Streamlit App                                        │
│    streamlit/ai_threat_scene_6_PRODUCTION.py           │
│                                                          │
│    Reads from: DynamoDB table                           │
│    Displays: Real-time threats                          │
│    Executes: Automated remediation                      │
└─────────────────────────────────────────────────────────┘
```

---

## 🚀 Quick Reference Commands

### Deploy Everything
```bash
./scripts/deploy.sh --email your@email.com
```

### Test System
```bash
./scripts/test.sh
```

### View Logs
```bash
aws logs tail /aws/lambda/threat-detection-handler --follow
```

### Query Threats
```bash
aws dynamodb scan --table-name security-threats --max-items 10
```

### Rollback
```bash
./scripts/rollback.sh
```

### Run Streamlit
```bash
cd streamlit
streamlit run your_app.py
```

---

## 💡 Key Integration Points

### 1. CloudFormation → Lambda
- CloudFormation creates Lambda function
- Lambda code uploaded separately
- IAM role grants permissions

### 2. EventBridge → Lambda
- EventBridge captures CloudTrail events
- Filters IAM/S3 changes
- Triggers Lambda on match

### 3. Lambda → DynamoDB
- Lambda stores threats
- Indexed by threat_id, timestamp, status
- Streamlit reads from indexes

### 4. Lambda → Bedrock
- Lambda calls Claude for AI analysis
- Returns threat assessment, compliance impact
- Stored in DynamoDB with threat

### 5. Lambda → SNS
- Lambda publishes alerts
- SNS sends to email/Slack/PagerDuty
- Configured in CloudFormation

### 6. Streamlit → DynamoDB
- Reads threats from indexes
- Displays in real-time
- Updates remediation status

---

## 📊 File Size & Complexity

| File | Lines | Complexity | Time to Deploy |
|------|-------|------------|----------------|
| cloudformation_threat_detection.yaml | 350 | Medium | 3-5 min |
| threat_detection_lambda.py | 450 | High | 30 sec |
| ai_threat_scene_6_PRODUCTION.py | 800 | High | Instant |
| deploy.sh | 350 | Medium | Runs in 5 min |
| test.sh | 150 | Low | Runs in 30 sec |
| rollback.sh | 80 | Low | Runs in 3 min |

---

## 🔐 Security Considerations

### CloudFormation
- ✅ Creates least-privilege IAM roles
- ✅ Enables encryption by default
- ✅ Configures VPC endpoints (optional)

### Lambda
- ✅ Environment variables encrypted
- ✅ Execution role has minimal permissions
- ✅ Logs to CloudWatch (retention: 30 days)

### DynamoDB
- ✅ Encryption at rest (AWS managed)
- ✅ Point-in-time recovery enabled
- ✅ Indexes for efficient queries

### Streamlit
- ⚠️ Use IAM roles (not access keys)
- ⚠️ Store secrets in .streamlit/secrets.toml
- ⚠️ Never commit secrets to git

---

## 🎯 Success Indicators

After deployment, verify:

- [ ] CloudFormation stack: `CREATE_COMPLETE`
- [ ] Lambda function: Can invoke manually
- [ ] DynamoDB table: Exists and accessible
- [ ] EventBridge rules: Enabled (3 rules)
- [ ] SNS subscription: Confirmed via email
- [ ] Streamlit: Connects to DynamoDB
- [ ] Test threat: Detected and stored

---

## 📞 Where to Look for Issues

| Issue | Check This File | Look For |
|-------|----------------|----------|
| Deployment fails | scripts/deploy.sh | Error messages in output |
| Lambda errors | lambda/threat_detection_lambda.py | Exception handling, line ~400+ |
| No threats detected | cloudformation/...yaml | EventBridge rule patterns |
| Streamlit blank | streamlit/ai_threat_scene_6_PRODUCTION.py | DynamoDB connection, line ~50 |
| Permission denied | cloudformation/...yaml | IAM role policies |
| High costs | docs/PRODUCTION_DEPLOYMENT_GUIDE.md | Cost section |

---

**Need help? Start with `README.md` → `QUICKSTART.md` → `scripts/deploy.sh`**
