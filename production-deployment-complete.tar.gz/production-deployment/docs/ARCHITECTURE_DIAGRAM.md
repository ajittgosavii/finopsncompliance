# 🏗️ Real Threat Detection Architecture
## Complete Data Flow Diagram

---

## 📊 High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────────────┐
│                          USER ACTIONS IN AWS                             │
│                                                                           │
│  Developer/User performs action:                                         │
│  $ aws iam put-role-policy --role-name DataAccessRole \                 │
│      --policy-name DataAccessPolicy --policy-document file://policy.json │
│                                                                           │
└───────────────────────────┬─────────────────────────────────────────────┘
                            │
                            │ API Call Executed
                            ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                     AWS CLOUDTRAIL (Event Capture)                       │
│                                                                           │
│  📝 Event Logged:                                                        │
│  {                                                                       │
│    "eventName": "PutRolePolicy",                                        │
│    "eventTime": "2025-11-25T14:23:18Z",                                 │
│    "userIdentity": {...},                                               │
│    "requestParameters": {...}                                           │
│  }                                                                       │
│                                                                           │
│  ✅ Stored in S3                                                         │
│  ✅ Available within seconds                                            │
│                                                                           │
└───────────────────────────┬─────────────────────────────────────────────┘
                            │
                            │ Event Published
                            ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                   AMAZON EVENTBRIDGE (Event Router)                      │
│                                                                           │
│  🎯 Rule: "detect-iam-policy-changes"                                   │
│                                                                           │
│  Event Pattern:                                                          │
│  {                                                                       │
│    "source": ["aws.iam"],                                               │
│    "detail-type": ["AWS API Call via CloudTrail"],                      │
│    "detail": {                                                           │
│      "eventName": [                                                      │
│        "PutRolePolicy", "AttachRolePolicy",                             │
│        "CreateAccessKey", "DeleteTrail", ...                            │
│      ]                                                                   │
│    }                                                                     │
│  }                                                                       │
│                                                                           │
│  ✅ Filters only security-relevant events                               │
│  ✅ Reduces Lambda invocations (cost savings)                           │
│                                                                           │
└───────────────────────────┬─────────────────────────────────────────────┘
                            │
                            │ Triggers Lambda
                            ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                    AWS LAMBDA (Threat Analysis)                          │
│                    Function: threat-detection-handler                    │
│                                                                           │
│  STEP 1: Extract Event Details                                          │
│  ├─ Event name, user, timestamp, IP                                     │
│  ├─ Resource affected, action performed                                 │
│  └─ Account ID, region                                                  │
│                                                                           │
│  STEP 2: Automated Threat Analysis                                      │
│  ├─ ✅ Check for high-risk actions                                      │
│  ├─ ✅ Detect root account usage                                        │
│  ├─ ✅ Identify after-hours activity                                    │
│  ├─ ✅ Scan for wildcard permissions (*)                                │
│  ├─ ✅ Detect privilege escalation                                      │
│  └─ ✅ Check compliance-sensitive resources                             │
│                                                                           │
│  STEP 3: Risk Scoring                                                   │
│  └─ Assign severity: CRITICAL | HIGH | MEDIUM | LOW                     │
│                                                                           │
└───────────────────────────┬─────────────────────────────────────────────┘
                            │
                            │ If threat detected
                            ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                    AWS BEDROCK (Claude AI Analysis)                      │
│                    Model: Claude 3.5 Sonnet                              │
│                                                                           │
│  🤖 AI Analysis Request:                                                │
│  "Analyze this security event..."                                       │
│                                                                           │
│  📊 AI Provides:                                                         │
│  ├─ Threat Assessment (risk level, impact)                              │
│  ├─ Compliance Impact (HIPAA, PCI-DSS, SOC 2)                          │
│  ├─ Pattern Detection (anomalies, insider threats)                      │
│  └─ Recommended Actions (prioritized remediation steps)                 │
│                                                                           │
│  ⏱️ Response time: ~1-2 seconds                                         │
│                                                                           │
└───────────────────────────┬─────────────────────────────────────────────┘
                            │
                            │ Store threat + AI analysis
                            ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                    AMAZON DYNAMODB (Threat Storage)                      │
│                    Table: security-threats                               │
│                                                                           │
│  📝 Threat Record:                                                       │
│  {                                                                       │
│    "threat_id": "THREAT-123456789-1732545798000",                       │
│    "timestamp": "2025-11-25T14:23:18Z",                                 │
│    "severity": "CRITICAL",                                              │
│    "event_name": "PutRolePolicy",                                       │
│    "account_id": "123456789012",                                        │
│    "user_arn": "arn:aws:iam::123456789012:user/dev-user-1247",        │
│    "resource_affected": "IAM Policy 'DataAccessPolicy'",               │
│    "threat_indicators": [...],                                          │
│    "ai_analysis": {                                                     │
│      "threat_assessment": "...",                                        │
│      "compliance_impact": ["HIPAA", "PCI-DSS"],                        │
│      "recommended_actions": [...]                                       │
│    },                                                                    │
│    "status": "ACTIVE",                                                  │
│    "event_details": {...}                                               │
│  }                                                                       │
│                                                                           │
│  🔍 Indexed by:                                                         │
│  ├─ threat_id (primary key)                                            │
│  ├─ timestamp (sort by time)                                           │
│  ├─ account_id + severity                                              │
│  └─ status + timestamp (active threats)                                │
│                                                                           │
└───────────────────────────┬─────────────────────────────────────────────┘
                            │
                            │ Send alert
                            ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                      AMAZON SNS (Alert Notifications)                    │
│                      Topic: security-threat-alerts                       │
│                                                                           │
│  📧 Email Alert Sent:                                                   │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │ From: AWS Notifications                                           │ │
│  │ To: security-team@company.com                                     │ │
│  │ Subject: 🚨 CRITICAL Security Threat: PutRolePolicy             │ │
│  │                                                                   │ │
│  │ Threat ID: THREAT-123456789-1732545798000                        │ │
│  │ Severity: CRITICAL                                               │ │
│  │ Event: PutRolePolicy                                             │ │
│  │ Account: prod-healthcare-01                                      │ │
│  │                                                                   │ │
│  │ AI Assessment: High risk - Wildcard permissions granted...      │ │
│  │                                                                   │ │
│  │ View in dashboard: https://your-app.com/threats                  │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                           │
│  🔔 Additional Integrations:                                            │
│  ├─ Slack webhook (optional)                                            │
│  ├─ PagerDuty (optional)                                                │
│  └─ Microsoft Teams (optional)                                          │
│                                                                           │
└───────────────────────────────────────────────────────────────────────────┘


                            ┌─────────────────┐
                            │  SECURITY TEAM  │
                            │   Gets Alert    │
                            └────────┬────────┘
                                     │
                                     │ Opens dashboard
                                     ▼
┌─────────────────────────────────────────────────────────────────────────┐
│               STREAMLIT APP (Cloud Compliance Canvas)                    │
│               Tab: AI-Powered Remediation → Threat Analysis              │
│                                                                           │
│  🔍 Reads from DynamoDB:                                                │
│                                                                           │
│  threats = dynamodb.query(                                              │
│    IndexName='status-timestamp-index',                                  │
│    KeyConditionExpression=Key('status').eq('ACTIVE')                    │
│  )                                                                       │
│                                                                           │
│  📊 Displays:                                                           │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │ 🚨 CRITICAL SECURITY ALERT                                      │   │
│  │ ⚠️ Requires immediate attention                                 │   │
│  │                                                                  │   │
│  │ Unauthorized IAM Policy Change                                  │   │
│  │                                                                  │   │
│  │ Account: prod-healthcare-01                                     │   │
│  │ Resource: IAM Policy "DataAccessPolicy"                         │   │
│  │ User: dev-user-1247                                             │   │
│  │ Time: 2025-11-25 14:23:18 UTC                                  │   │
│  │                                                                  │   │
│  │ [🤖 Analyze with AI]  [📋 View Details]                        │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                           │
│  User clicks "🤖 Analyze with AI":                                      │
│  ├─ Shows AI threat assessment                                          │
│  ├─ Shows compliance impact                                             │
│  ├─ Shows pattern detection                                             │
│  └─ Shows recommended actions                                           │
│                                                                           │
└───────────────────────────┬─────────────────────────────────────────────┘
                            │
                            │ User clicks "🚀 Execute Remediation"
                            ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                   AUTOMATED REMEDIATION WORKFLOW                         │
│                                                                           │
│  Action 1: Revert IAM Policy                                            │
│  └─ boto3: iam.delete_role_policy(RoleName=..., PolicyName=...)        │
│                                                                           │
│  Action 2: Rotate Credentials                                           │
│  └─ boto3: iam.delete_access_key(UserName=..., AccessKeyId=...)        │
│                                                                           │
│  Action 3: Generate CloudTrail Report                                   │
│  └─ boto3: cloudtrail.lookup_events(...)                               │
│                                                                           │
│  Action 4: Deploy Preventive SCP                                        │
│  └─ boto3: organizations.attach_policy(...)                            │
│                                                                           │
│  Action 5: Create Jira Ticket                                           │
│  └─ HTTP: POST to Jira API                                             │
│                                                                           │
│  Action 6: Notify SOC                                                   │
│  └─ boto3: sns.publish(...)                                            │
│                                                                           │
│  Action 7: Quarantine User                                              │
│  └─ boto3: iam.put_user_policy(..., DenyAll policy)                    │
│                                                                           │
│  ✅ Update DynamoDB:                                                    │
│  └─ status = "REMEDIATED", remediation_results = {...}                 │
│                                                                           │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 🔄 End-to-End Timeline

```
0ms     - User executes: aws iam put-role-policy
100ms   - CloudTrail captures event
200ms   - EventBridge receives event
300ms   - EventBridge triggers Lambda
500ms   - Lambda begins analysis
1500ms  - Lambda invokes Claude AI via Bedrock
3500ms  - AI analysis complete
4000ms  - Threat stored in DynamoDB
4100ms  - SNS alert sent
4200ms  - Email received
4500ms  - Streamlit displays threat (next page refresh)

Total: ~4.5 seconds from action to alert
```

---

## 📈 Scalability

```
Event Volume          Lambda Invocations    Cost Impact
─────────────────────────────────────────────────────────
1,000 events/day   → ~50 threats/day    → ~$0.35/day
10,000 events/day  → ~500 threats/day   → ~$3.50/day
100,000 events/day → ~5,000 threats/day → ~$35/day
```

**EventBridge Filtering** reduces Lambda invocations by ~95%
- Without filtering: 100,000 events → 100,000 Lambda calls
- With filtering: 100,000 events → 5,000 Lambda calls (IAM/S3 only)

---

## 🔐 Security Layers

```
Layer 1: CloudTrail
├─ Log validation enabled
├─ Encrypted at rest (S3-SSE)
└─ Multi-region logging

Layer 2: EventBridge
├─ Event filtering (reduces attack surface)
└─ Encryption in transit

Layer 3: Lambda
├─ VPC deployment (optional)
├─ Environment variable encryption
├─ IAM least-privilege role
└─ CloudWatch logging

Layer 4: DynamoDB
├─ Encryption at rest (AWS managed keys)
├─ Point-in-time recovery enabled
├─ VPC endpoints (optional)
└─ Fine-grained access control

Layer 5: Bedrock
├─ Request/response encryption
├─ No data retention (ephemeral)
└─ Regional isolation

Layer 6: SNS
├─ Encryption at rest
├─ TLS for delivery
└─ Access policies
```

---

## 💾 Data Flow Summary

| Step | Service | Action | Latency | Data Size |
|------|---------|--------|---------|-----------|
| 1 | CloudTrail | Capture API call | ~100ms | ~2KB |
| 2 | EventBridge | Filter & route | ~100ms | ~2KB |
| 3 | Lambda | Analyze threat | ~1000ms | ~5KB |
| 4 | Bedrock | AI analysis | ~2000ms | ~10KB |
| 5 | DynamoDB | Store threat | ~50ms | ~15KB |
| 6 | SNS | Send alert | ~100ms | ~3KB |
| 7 | Streamlit | Display | ~200ms | ~15KB |

**Total**: ~3.5 seconds, ~52KB data processed

---

## 🎯 Detection Capabilities

### What Gets Detected

✅ **IAM Changes**
- Policy creation/modification
- Role privilege escalation
- Access key creation
- User creation

✅ **S3 Security**
- Public bucket exposure
- Bucket policy changes
- ACL modifications

✅ **CloudTrail Tampering**
- Trail deletion
- Logging disabled
- Configuration changes

✅ **Compliance Violations**
- HIPAA-regulated resource access
- PCI-DSS scope changes
- GDPR data access

✅ **Threat Indicators**
- Root account usage
- After-hours activity
- Unusual API rate
- Privilege escalation
- Wildcard permissions

### What Doesn't Get Detected (Yet)

❌ **Network Security**
- Security group changes (can be added)
- VPC modifications (can be added)

❌ **Compute Security**
- EC2 instance launches (can be added)
- Lambda function changes (can be added)

❌ **Data Access**
- S3 object reads (requires S3 access logs)
- Database queries (requires VPC flow logs)

**All of these can be added by creating additional EventBridge rules!**

---

## 🚀 Future Enhancements

1. **Machine Learning** - Train models on threat patterns
2. **Behavioral Analysis** - Detect anomalous user behavior
3. **Threat Intelligence** - Integration with external feeds
4. **Automated Response** - Pre-approved auto-remediation
5. **Cross-Account Detection** - AWS Organizations support
6. **SIEM Integration** - Splunk, Sumo Logic, etc.
