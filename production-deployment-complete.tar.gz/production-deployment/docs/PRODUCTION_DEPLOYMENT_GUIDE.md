# 🚀 Production Deployment Guide
## Real-Time Threat Detection System

---

## 📋 Overview

This guide will help you deploy a **production-ready** real-time threat detection system that replaces demo data with actual AWS threat monitoring.

### What You're Deploying

```
┌─────────────────────────────────────────────────────────────┐
│                    ARCHITECTURE                              │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  AWS Account (Production)                                   │
│       │                                                      │
│       ├─> CloudTrail (captures all API calls)              │
│       │       │                                             │
│       │       └─> EventBridge (filters IAM/S3 events)      │
│       │                │                                    │
│       │                └─> Lambda (threat detection)        │
│       │                      │                              │
│       │                      ├─> Claude AI (Bedrock)        │
│       │                      ├─> DynamoDB (stores threats)  │
│       │                      └─> SNS (sends alerts)         │
│       │                                                      │
│       └─> Streamlit App (reads from DynamoDB)              │
│                   │                                          │
│                   └─> Displays real-time threats            │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

---

## 📦 Prerequisites

### 1. AWS Account Setup

- ✅ Active AWS account with admin access
- ✅ CloudTrail enabled (organization-wide or per-account)
- ✅ AWS Bedrock access (Claude 3.5 Sonnet model enabled)
- ✅ AWS CLI configured with credentials

### 2. Required Permissions

You'll need permissions for:
- CloudFormation (to deploy stack)
- IAM (to create roles and policies)
- Lambda, DynamoDB, EventBridge, SNS
- Bedrock (to invoke Claude AI)

### 3. Local Requirements

```bash
# Install AWS CLI
pip install awscli

# Install boto3 for Streamlit app
pip install boto3 streamlit pandas plotly
```

---

## 🚀 Step-by-Step Deployment

### Step 1: Enable CloudTrail (If Not Already Enabled)

```bash
# Create a CloudTrail trail
aws cloudtrail create-trail \
    --name security-monitoring-trail \
    --s3-bucket-name your-cloudtrail-bucket \
    --is-multi-region-trail \
    --is-organization-trail  # Optional: for AWS Organizations

# Start logging
aws cloudtrail start-logging \
    --name security-monitoring-trail
```

### Step 2: Enable AWS Bedrock (Claude 3.5 Sonnet)

```bash
# Check if Bedrock is available in your region
aws bedrock list-foundation-models \
    --region us-east-1 \
    --query 'modelSummaries[?modelId==`anthropic.claude-3-5-sonnet-20241022-v2:0`]'

# Enable model access in AWS Console:
# https://console.aws.amazon.com/bedrock/home#/modelaccess
```

### Step 3: Deploy CloudFormation Stack

```bash
# Deploy the infrastructure
aws cloudformation create-stack \
    --stack-name threat-detection-system \
    --template-body file://cloudformation_threat_detection.yaml \
    --parameters ParameterKey=NotificationEmail,ParameterValue=your-email@example.com \
    --capabilities CAPABILITY_NAMED_IAM \
    --region us-east-1

# Wait for stack creation
aws cloudformation wait stack-create-complete \
    --stack-name threat-detection-system \
    --region us-east-1

# Get outputs
aws cloudformation describe-stacks \
    --stack-name threat-detection-system \
    --query 'Stacks[0].Outputs'
```

### Step 4: Deploy Lambda Function Code

```bash
# Package the Lambda function
zip threat_detection_lambda.zip threat_detection_lambda.py

# Update Lambda function
aws lambda update-function-code \
    --function-name threat-detection-handler \
    --zip-file fileb://threat_detection_lambda.zip \
    --region us-east-1

# Verify deployment
aws lambda get-function \
    --function-name threat-detection-handler \
    --query 'Configuration.LastModified'
```

### Step 5: Configure Streamlit App

Create `.streamlit/secrets.toml`:

```toml
[aws]
region = "us-east-1"
threats_table = "security-threats"
sns_topic_arn = "arn:aws:sns:us-east-1:123456789012:security-threat-alerts"

[default]
aws_access_key_id = "YOUR_ACCESS_KEY"
aws_secret_access_key = "YOUR_SECRET_KEY"
```

**Security Best Practice:** Use IAM roles instead of access keys:

```python
# In your Streamlit app, boto3 will automatically use IAM role if running on EC2/ECS
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
```

### Step 6: Update Streamlit App Code

Replace the import in your main `streamlit_app.py`:

```python
# OLD (Demo version)
from ai_threat_scene_6_complete import render_ai_threat_analysis_scene

# NEW (Production version)
from ai_threat_scene_6_PRODUCTION import render_ai_threat_analysis_scene
```

### Step 7: Test the System

#### A. Generate a Test Threat

```bash
# Create a test IAM policy change (will trigger detection)
aws iam put-role-policy \
    --role-name TestRole \
    --policy-name TestPolicy \
    --policy-document '{
        "Version": "2012-10-17",
        "Statement": [{
            "Effect": "Allow",
            "Action": "s3:*",
            "Resource": "*"
        }]
    }'
```

#### B. Verify Detection

```bash
# Check Lambda logs
aws logs tail /aws/lambda/threat-detection-handler --follow

# Query DynamoDB
aws dynamodb scan \
    --table-name security-threats \
    --max-items 5
```

#### C. View in Streamlit

```bash
streamlit run streamlit_app.py
```

Navigate to: **AI-Powered Remediation → Threat Analysis**

You should see the real threat!

---

## 🔧 Configuration Options

### Lambda Environment Variables

Edit in CloudFormation or AWS Console:

| Variable | Purpose | Example |
|----------|---------|---------|
| `THREATS_TABLE` | DynamoDB table name | `security-threats` |
| `SNS_TOPIC_ARN` | Alert destination | `arn:aws:sns:...` |
| `BEDROCK_REGION` | Bedrock API region | `us-east-1` |

### EventBridge Rules

Add more event patterns to detect additional threats:

```json
{
  "source": ["aws.ec2"],
  "detail-type": ["AWS API Call via CloudTrail"],
  "detail": {
    "eventSource": ["ec2.amazonaws.com"],
    "eventName": [
      "AuthorizeSecurityGroupIngress",
      "CreateSecurityGroup"
    ]
  }
}
```

### DynamoDB TTL (Optional)

Auto-delete old threats after 90 days:

```bash
aws dynamodb update-time-to-live \
    --table-name security-threats \
    --time-to-live-specification \
        "Enabled=true, AttributeName=ttl"
```

---

## 📊 Monitoring & Operations

### CloudWatch Dashboards

Create a dashboard to monitor your system:

```bash
aws cloudwatch put-dashboard \
    --dashboard-name ThreatDetectionMonitoring \
    --dashboard-body file://dashboard.json
```

### Key Metrics to Monitor

1. **Lambda Invocations** - Should match CloudTrail event volume
2. **Lambda Errors** - Should be near zero
3. **DynamoDB Read/Write Units** - Track costs
4. **SNS Deliveries** - Verify alerts are sent

### Alerts to Configure

```bash
# Alert on Lambda errors
aws cloudwatch put-metric-alarm \
    --alarm-name threat-detection-errors \
    --metric-name Errors \
    --namespace AWS/Lambda \
    --statistic Sum \
    --period 300 \
    --evaluation-periods 1 \
    --threshold 5 \
    --comparison-operator GreaterThanThreshold \
    --dimensions Name=FunctionName,Value=threat-detection-handler \
    --alarm-actions arn:aws:sns:us-east-1:123456789012:security-threat-alerts
```

---

## 🔐 Security Best Practices

### 1. Least Privilege IAM

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "dynamodb:GetItem",
        "dynamodb:Query",
        "dynamodb:Scan"
      ],
      "Resource": "arn:aws:dynamodb:*:*:table/security-threats"
    }
  ]
}
```

### 2. Encrypt Data at Rest

- ✅ DynamoDB encryption enabled (default)
- ✅ Lambda environment variables encrypted
- ✅ SNS encryption with KMS

### 3. VPC Deployment (Optional)

Deploy Lambda in VPC for additional security:

```yaml
VpcConfig:
  SecurityGroupIds:
    - sg-xxxxxx
  SubnetIds:
    - subnet-xxxxxx
    - subnet-yyyyyy
```

### 4. CloudTrail Log Validation

```bash
# Enable log file validation
aws cloudtrail update-trail \
    --name security-monitoring-trail \
    --enable-log-file-validation
```

---

## 💰 Cost Estimation

### Monthly Costs (Approximate)

| Service | Usage | Cost |
|---------|-------|------|
| **CloudTrail** | 1M events | $2.00 |
| **Lambda** | 100K invocations | $0.20 |
| **DynamoDB** | On-demand, 1K reads/writes | $1.25 |
| **Bedrock (Claude)** | 1K requests, 2K tokens avg | $6.00 |
| **SNS** | 100 notifications | $0.05 |
| **EventBridge** | 100K events | $1.00 |
| **Data Transfer** | 1GB | $0.09 |
| **Total** | | **~$10.59/month** |

**Note:** Costs scale with event volume. Monitor with AWS Cost Explorer.

---

## 🐛 Troubleshooting

### Issue: No threats being detected

**Check:**
1. CloudTrail is logging: `aws cloudtrail get-trail-status --name security-monitoring-trail`
2. EventBridge rules are enabled: `aws events list-rules`
3. Lambda has permissions: Check IAM role
4. Lambda logs for errors: `aws logs tail /aws/lambda/threat-detection-handler --follow`

### Issue: Lambda timeouts

**Solution:**
- Increase Lambda timeout: Update CloudFormation `Timeout: 120`
- Increase Lambda memory: Update CloudFormation `MemorySize: 1024`

### Issue: Bedrock "Model not found"

**Solution:**
- Enable model access in Bedrock console
- Verify region supports Claude 3.5 Sonnet
- Check IAM permissions for `bedrock:InvokeModel`

### Issue: DynamoDB "ResourceNotFoundException"

**Solution:**
- Verify table name matches: `security-threats`
- Check region: Table must be in same region as Lambda
- Wait for CloudFormation completion

### Issue: Streamlit can't connect to AWS

**Solution:**
```bash
# Verify AWS credentials
aws sts get-caller-identity

# Test DynamoDB access
aws dynamodb describe-table --table-name security-threats

# Check boto3 configuration
python -c "import boto3; print(boto3.client('dynamodb').describe_table(TableName='security-threats'))"
```

---

## 🔄 Maintenance & Updates

### Weekly Tasks
- ✅ Review threat logs
- ✅ Check false positive rate
- ✅ Update threat indicators if needed

### Monthly Tasks
- ✅ Review costs in AWS Cost Explorer
- ✅ Analyze threat patterns
- ✅ Update Lambda code if needed
- ✅ Review and tune EventBridge rules

### Quarterly Tasks
- ✅ Review and update security policies
- ✅ Audit IAM permissions
- ✅ Test disaster recovery procedures

---

## 📚 Additional Resources

### AWS Documentation
- [CloudTrail User Guide](https://docs.aws.amazon.com/cloudtrail/)
- [EventBridge User Guide](https://docs.aws.amazon.com/eventbridge/)
- [Bedrock User Guide](https://docs.aws.amazon.com/bedrock/)
- [Lambda Best Practices](https://docs.aws.amazon.com/lambda/latest/dg/best-practices.html)

### Compliance Resources
- [AWS Security Hub Standards](https://docs.aws.amazon.com/securityhub/latest/userguide/standards-reference.html)
- [HIPAA Compliance](https://aws.amazon.com/compliance/hipaa-compliance/)
- [PCI DSS on AWS](https://aws.amazon.com/compliance/pci-dss-level-1-faqs/)

---

## 🎯 Success Checklist

Before going live, verify:

- [ ] CloudTrail is logging all required events
- [ ] EventBridge rules are triggering Lambda
- [ ] Lambda can invoke Bedrock (Claude AI)
- [ ] Threats are being stored in DynamoDB
- [ ] SNS alerts are being received
- [ ] Streamlit app can read from DynamoDB
- [ ] All IAM roles have least-privilege permissions
- [ ] Encryption is enabled for all services
- [ ] Cost monitoring is configured
- [ ] CloudWatch alarms are set up
- [ ] Backup/disaster recovery tested
- [ ] Team trained on using the system

---

## 🆘 Support

For issues or questions:

1. **Check CloudWatch Logs:** `/aws/lambda/threat-detection-handler`
2. **Review DynamoDB items:** Use AWS Console or CLI
3. **Test Lambda manually:** Use AWS Console test feature
4. **Verify permissions:** Use IAM Policy Simulator

---

**🎉 Congratulations! You now have a production-ready real-time threat detection system!**

**Next Steps:**
1. Monitor for first week to tune detection rules
2. Train your team on remediation procedures
3. Document your organization's threat response process
4. Schedule regular reviews of threat patterns
