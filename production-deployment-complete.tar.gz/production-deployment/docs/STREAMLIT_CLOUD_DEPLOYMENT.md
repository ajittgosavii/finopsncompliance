# 🌥️ Deploying to Streamlit Cloud
## Production Threat Detection with Streamlit Cloud

---

## ⚠️ Important Considerations

### The Challenge

Streamlit Cloud runs in a **containerized environment** where:
- ❌ You cannot run bash scripts directly
- ❌ AWS CLI is not installed by default
- ❌ You shouldn't store admin AWS credentials in Streamlit Cloud
- ✅ You CAN use boto3 (Python) to read from AWS
- ✅ You CAN trigger deployments via UI

### The Solution

**We'll use a HYBRID approach:**
1. Deploy AWS infrastructure **once** (from your local machine or GitHub Actions)
2. Streamlit Cloud app **reads** threat data (read-only access)
3. Optionally: Add deployment UI for future updates

---

## 🎯 Recommended Approach: Separate Deployment

### Step 1: Deploy AWS Infrastructure (One-Time)

**On your local machine:**

```bash
# Download the deployment package
cd production-deployment

# Deploy AWS infrastructure
./scripts/deploy.sh --email your-email@company.com

# This creates:
# - DynamoDB table: security-threats
# - Lambda function: threat-detection-handler
# - EventBridge rules
# - SNS alerts
```

**Time:** 5 minutes  
**Frequency:** Once (or when updating infrastructure)

### Step 2: Create Streamlit Cloud App

**Your GitHub repository structure:**

```
your-streamlit-repo/
├── streamlit_app.py                    # Your main app
├── ai_threat_scene_6_PRODUCTION.py    # Copy from our package
├── requirements.txt
├── .streamlit/
│   └── secrets.toml.example           # Example secrets file
└── README.md
```

**In your `streamlit_app.py`:**

```python
import streamlit as st
from ai_threat_scene_6_PRODUCTION import render_ai_threat_analysis_scene

# Your existing tabs
with tabs[4]:  # AI Remediation tab
    st.markdown("## 🤖 AI-Powered Remediation")
    
    ai_tabs = st.tabs([
        "🔍 Threat Analysis",
        "AI Insights",
        "Code Generation",
        "Batch Remediation"
    ])
    
    with ai_tabs[0]:
        # NEW: Production version with real AWS
        render_ai_threat_analysis_scene()
```

### Step 3: Configure Streamlit Cloud Secrets

**In Streamlit Cloud dashboard:**

1. Go to: `Settings → Secrets`
2. Add this configuration:

```toml
[aws]
region = "us-east-1"
threats_table = "security-threats"
sns_topic_arn = "arn:aws:sns:us-east-1:YOUR_ACCOUNT_ID:security-threat-alerts"

# AWS Credentials (READ-ONLY role recommended)
[default]
aws_access_key_id = "AKIA..."
aws_secret_access_key = "..."
```

### Step 4: Deploy to Streamlit Cloud

1. Push code to GitHub
2. Connect GitHub repo to Streamlit Cloud
3. Deploy!

**Your app now shows REAL threats from AWS!**

---

## 🔐 Security Best Practice: IAM Read-Only Role

### Create Read-Only IAM User (Recommended)

Instead of using admin credentials, create a dedicated read-only user:

```bash
# 1. Create IAM policy for Streamlit
cat > streamlit-readonly-policy.json <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "dynamodb:GetItem",
        "dynamodb:Query",
        "dynamodb:Scan"
      ],
      "Resource": [
        "arn:aws:dynamodb:us-east-1:YOUR_ACCOUNT_ID:table/security-threats",
        "arn:aws:dynamodb:us-east-1:YOUR_ACCOUNT_ID:table/security-threats/index/*"
      ]
    },
    {
      "Effect": "Allow",
      "Action": [
        "bedrock:InvokeModel"
      ],
      "Resource": "arn:aws:bedrock:us-east-1::foundation-model/anthropic.claude-3-5-sonnet-*"
    }
  ]
}
EOF

# 2. Create the policy
aws iam create-policy \
    --policy-name StreamlitThreatReaderPolicy \
    --policy-document file://streamlit-readonly-policy.json

# 3. Create IAM user
aws iam create-user --user-name streamlit-threat-reader

# 4. Attach policy
aws iam attach-user-policy \
    --user-name streamlit-threat-reader \
    --policy-arn arn:aws:iam::YOUR_ACCOUNT_ID:policy/StreamlitThreatReaderPolicy

# 5. Create access keys
aws iam create-access-key --user-name streamlit-threat-reader
```

**Use these access keys in Streamlit Cloud secrets!**

---

## 🚀 Alternative: Deployment UI in Streamlit (Advanced)

If you want to deploy AWS infrastructure FROM Streamlit Cloud, you can create a deployment interface.

### ⚠️ Security Warning

This requires storing **admin AWS credentials** in Streamlit Cloud, which is **NOT recommended for production**. Use this only for:
- Development/testing environments
- Internal tools with restricted access
- POC/demo purposes

### Implementation

Create a new file: `deployment_interface.py`

```python
import streamlit as st
import boto3
import json
from botocore.exceptions import ClientError

def render_deployment_interface():
    """
    Streamlit UI for deploying AWS infrastructure
    USE WITH CAUTION - Requires admin AWS credentials
    """
    
    st.markdown("## 🚀 AWS Infrastructure Deployment")
    
    st.warning("""
    ⚠️ **Security Warning**: This interface requires AWS credentials with 
    CloudFormation and IAM permissions. Only use in secure environments.
    """)
    
    # Deployment configuration
    with st.form("deployment_form"):
        stack_name = st.text_input("Stack Name", value="threat-detection-system")
        notification_email = st.text_input("Notification Email", value="")
        aws_region = st.selectbox("AWS Region", ["us-east-1", "us-west-2", "eu-west-1"])
        
        submitted = st.form_submit_button("🚀 Deploy Infrastructure")
    
    if submitted:
        if not notification_email:
            st.error("Please enter notification email")
            return
        
        with st.spinner("Deploying AWS infrastructure..."):
            try:
                # Read CloudFormation template
                with open('cloudformation_threat_detection.yaml', 'r') as f:
                    template_body = f.read()
                
                # Create CloudFormation client
                cf = boto3.client('cloudformation', region_name=aws_region)
                
                # Deploy stack
                response = cf.create_stack(
                    StackName=stack_name,
                    TemplateBody=template_body,
                    Parameters=[
                        {
                            'ParameterKey': 'NotificationEmail',
                            'ParameterValue': notification_email
                        }
                    ],
                    Capabilities=['CAPABILITY_NAMED_IAM']
                )
                
                st.success(f"✅ Deployment started! Stack ID: {response['StackId']}")
                
                # Monitor deployment
                with st.expander("📊 Deployment Progress", expanded=True):
                    monitor_deployment(cf, stack_name)
                
            except ClientError as e:
                st.error(f"❌ Deployment failed: {str(e)}")


def monitor_deployment(cf_client, stack_name):
    """Monitor CloudFormation stack deployment"""
    
    import time
    
    status_placeholder = st.empty()
    progress_bar = st.progress(0)
    
    statuses_seen = set()
    
    for i in range(60):  # Max 5 minutes
        try:
            response = cf_client.describe_stacks(StackName=stack_name)
            stack = response['Stacks'][0]
            status = stack['StackStatus']
            
            # Update progress
            if status not in statuses_seen:
                statuses_seen.add(status)
                status_placeholder.info(f"Status: {status}")
            
            progress_bar.progress(min((i + 1) / 60, 0.99))
            
            # Check if complete
            if 'COMPLETE' in status or 'FAILED' in status:
                if 'CREATE_COMPLETE' in status:
                    progress_bar.progress(1.0)
                    st.success("✅ Deployment complete!")
                    
                    # Show outputs
                    outputs = stack.get('Outputs', [])
                    if outputs:
                        st.markdown("### 📊 Stack Outputs")
                        for output in outputs:
                            st.code(f"{output['OutputKey']}: {output['OutputValue']}")
                else:
                    st.error(f"❌ Deployment failed with status: {status}")
                break
            
            time.sleep(5)
            
        except Exception as e:
            st.error(f"Error monitoring deployment: {str(e)}")
            break


def render_lambda_deployment():
    """Deploy Lambda function code"""
    
    st.markdown("### 📦 Update Lambda Function")
    
    if st.button("🔄 Update Lambda Code"):
        with st.spinner("Uploading Lambda code..."):
            try:
                lambda_client = boto3.client('lambda', region_name='us-east-1')
                
                # Read Lambda code
                import zipfile
                import io
                
                # Create zip file in memory
                zip_buffer = io.BytesIO()
                with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
                    zip_file.write('threat_detection_lambda.py')
                
                # Upload to Lambda
                response = lambda_client.update_function_code(
                    FunctionName='threat-detection-handler',
                    ZipFile=zip_buffer.getvalue()
                )
                
                st.success(f"✅ Lambda updated! Version: {response['Version']}")
                
            except Exception as e:
                st.error(f"❌ Update failed: {str(e)}")


# Add to your main app
if st.sidebar.checkbox("🔧 Show Deployment Interface", value=False):
    render_deployment_interface()
    render_lambda_deployment()
```

---

## 📋 Streamlit Cloud Requirements File

**Update your `requirements.txt`:**

```txt
streamlit==1.29.0
boto3==1.34.59
pandas==2.1.4
plotly==5.18.0
python-dateutil==2.8.2

# Optional: for deployment interface
pyyaml==6.0.1
```

---

## 🎯 Recommended Workflow

### Option 1: Simple (Recommended for Most Users)

```
1. Deploy AWS (local machine)
   └─> Run: ./scripts/deploy.sh
   └─> Time: 5 minutes
   └─> Frequency: Once

2. Update Streamlit (GitHub)
   └─> Copy: ai_threat_scene_6_PRODUCTION.py
   └─> Update: streamlit_app.py import
   └─> Push to GitHub

3. Configure Streamlit Cloud
   └─> Add: AWS credentials (read-only)
   └─> Deploy: Connect GitHub repo

4. Done!
   └─> App shows real threats
```

**Pros:**
- ✅ Most secure (separate credentials)
- ✅ Simplest setup
- ✅ Best for production

**Cons:**
- ❌ Infrastructure updates require local deployment

---

### Option 2: GitHub Actions (Best for Teams)

**Use GitHub Actions to deploy AWS infrastructure:**

Create `.github/workflows/deploy-aws.yml`:

```yaml
name: Deploy AWS Infrastructure

on:
  workflow_dispatch:
    inputs:
      email:
        description: 'Notification Email'
        required: true

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Configure AWS Credentials
        uses: aws-actions/configure-aws-credentials@v2
        with:
          aws-access-key-id: ${{ secrets.AWS_ACCESS_KEY_ID }}
          aws-secret-access-key: ${{ secrets.AWS_SECRET_ACCESS_KEY }}
          aws-region: us-east-1
      
      - name: Deploy CloudFormation
        run: |
          aws cloudformation create-stack \
            --stack-name threat-detection-system \
            --template-body file://cloudformation/cloudformation_threat_detection.yaml \
            --parameters ParameterKey=NotificationEmail,ParameterValue=${{ github.event.inputs.email }} \
            --capabilities CAPABILITY_NAMED_IAM
```

**Store AWS credentials in GitHub Secrets, trigger deployment from GitHub UI!**

**Pros:**
- ✅ Very secure (credentials in GitHub Secrets)
- ✅ Version controlled
- ✅ Audit trail
- ✅ Team collaboration

---

### Option 3: Deployment UI (Only for Dev/Demo)

```
1. Store CloudFormation template in repo
2. Add deployment_interface.py to Streamlit
3. Store ADMIN credentials in Streamlit secrets (⚠️)
4. Deploy from Streamlit UI
```

**Pros:**
- ✅ Everything in one interface
- ✅ No local setup needed

**Cons:**
- ❌ Security risk (admin credentials in Streamlit)
- ❌ Not recommended for production
- ❌ Requires careful access control

---

## 🔐 Security Comparison

| Approach | Security | Ease of Use | Best For |
|----------|----------|-------------|----------|
| **Local Deployment** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | Production |
| **GitHub Actions** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | Teams |
| **Streamlit UI** | ⭐⭐ | ⭐⭐⭐⭐⭐ | Dev/Demo only |

---

## 📝 Complete Setup Example (Recommended)

### Step-by-Step for Streamlit Cloud

**1. Deploy AWS (Local - One Time)**

```bash
# On your machine
cd production-deployment
./scripts/deploy.sh --email your@email.com

# Note the outputs:
# - DynamoDB table: security-threats
# - SNS topic ARN: arn:aws:sns:...
```

**2. Create GitHub Repository**

```bash
mkdir my-streamlit-app
cd my-streamlit-app

# Copy production file
cp /path/to/production-deployment/streamlit/ai_threat_scene_6_PRODUCTION.py .

# Create main app
cat > streamlit_app.py <<'EOF'
import streamlit as st
from ai_threat_scene_6_PRODUCTION import render_ai_threat_analysis_scene

st.set_page_config(page_title="Cloud Compliance Canvas", layout="wide")

# Your existing app code...

# Add threat analysis tab
with tabs[4]:
    st.markdown("## 🤖 AI-Powered Remediation")
    ai_tabs = st.tabs(["🔍 Threat Analysis", "AI Insights", "Code Generation", "Batch Remediation"])
    
    with ai_tabs[0]:
        render_ai_threat_analysis_scene()
EOF

# Create requirements
cat > requirements.txt <<EOF
streamlit==1.29.0
boto3==1.34.59
pandas==2.1.4
plotly==5.18.0
EOF

# Create example secrets
cat > .streamlit/secrets.toml.example <<EOF
[aws]
region = "us-east-1"
threats_table = "security-threats"
sns_topic_arn = "YOUR_SNS_TOPIC_ARN"

[default]
aws_access_key_id = "YOUR_ACCESS_KEY"
aws_secret_access_key = "YOUR_SECRET_KEY"
EOF

# Initialize git
git init
git add .
git commit -m "Initial commit with production threat detection"
git push origin main
```

**3. Deploy to Streamlit Cloud**

1. Go to https://share.streamlit.io
2. Click "New app"
3. Connect your GitHub repository
4. Select `streamlit_app.py`
5. Click "Advanced settings"
6. Add secrets:

```toml
[aws]
region = "us-east-1"
threats_table = "security-threats"
sns_topic_arn = "arn:aws:sns:us-east-1:123456789012:security-threat-alerts"

[default]
aws_access_key_id = "AKIA..."
aws_secret_access_key = "..."
```

7. Click "Deploy"!

**4. Verify It Works**

```bash
# Create a test threat in AWS
aws iam put-role-policy \
    --role-name TestRole \
    --policy-name Test \
    --policy-document '{
        "Version": "2012-10-17",
        "Statement": [{
            "Effect": "Allow",
            "Action": "s3:*",
            "Resource": "*"
        }]
    }'

# Wait 5 seconds, then refresh Streamlit app
# You should see the threat!
```

---

## 🎯 Final Recommendation

**For Streamlit Cloud:**

1. ✅ **Deploy AWS infrastructure locally** (5 minutes, one-time)
2. ✅ **Create read-only IAM user** (secure)
3. ✅ **Push code to GitHub** (version controlled)
4. ✅ **Deploy to Streamlit Cloud** (use read-only credentials)

**Result:**
- 🔐 Secure (separate credentials, least privilege)
- 🚀 Fast (AWS already deployed)
- 📊 Real-time (shows actual threats)
- 💰 Cost-effective (~$10.50/month)

---

## 📞 Need Help?

**Common Issues:**

1. **"boto3 not found"**
   - Add `boto3==1.34.59` to requirements.txt

2. **"Access Denied" from DynamoDB**
   - Check AWS credentials in Streamlit secrets
   - Verify IAM policy allows DynamoDB read

3. **"Table not found"**
   - Verify AWS infrastructure is deployed
   - Check table name: `security-threats`

4. **"No threats showing"**
   - Wait 5 minutes after AWS deployment
   - Create test threat (see verification step above)

---

## 🎉 You're Ready!

**Your Streamlit Cloud app will now:**
- ✅ Show real AWS threats (not demo data)
- ✅ Update in real-time (<5 seconds)
- ✅ Display AI analysis from Claude
- ✅ Execute automated remediation
- ✅ Work from anywhere (cloud-hosted)

**Deploy and monitor threats from Streamlit Cloud!** 🚀
