# 🚀 Production Threat Detection System
## Cloud Compliance Canvas - Real AWS Integration

This package contains everything you need to deploy a **production-ready** real-time threat detection system that replaces demo data with actual AWS monitoring.

---

## 📦 What's Included

```
production-deployment/
├── cloudformation/
│   └── cloudformation_threat_detection.yaml    # AWS infrastructure
├── lambda/
│   ├── threat_detection_lambda.py              # Detection logic
│   └── requirements.txt                        # Dependencies
├── streamlit/
│   ├── ai_threat_scene_6_PRODUCTION.py        # Production UI
│   └── requirements.txt                        # Dependencies
├── scripts/
│   ├── deploy.sh                               # Automated deployment ⭐
│   ├── rollback.sh                             # Cleanup script
│   └── test.sh                                 # Testing suite
├── docs/
│   ├── PRODUCTION_DEPLOYMENT_GUIDE.md          # Detailed guide
│   └── ARCHITECTURE_DIAGRAM.md                 # System architecture
└── README.md                                    # This file
```

---

## ⚡ Quick Start (5 Minutes)

### Prerequisites

1. **AWS Account** with admin access
2. **AWS CLI** installed and configured
3. **Python 3.9+** installed
4. **Email address** for security alerts

### One-Command Deployment

```bash
# Make scripts executable
chmod +x scripts/*.sh

# Deploy everything
./scripts/deploy.sh --email your-email@company.com --region us-east-1
```

That's it! The script will:
- ✅ Enable CloudTrail
- ✅ Check Bedrock (Claude AI) access
- ✅ Deploy all AWS infrastructure
- ✅ Configure Lambda function
- ✅ Run tests
- ✅ Generate Streamlit configuration

---

## 📋 Step-by-Step Deployment

If you prefer manual deployment or want to understand each step:

### Step 1: Verify Prerequisites

```bash
# Check AWS CLI
aws --version

# Verify credentials
aws sts get-caller-identity

# Check Python
python3 --version
```

### Step 2: Enable AWS Bedrock

1. Go to: https://console.aws.amazon.com/bedrock/home#/modelaccess
2. Request access to: **Claude 3.5 Sonnet**
3. Wait for approval (~5 minutes)

### Step 3: Deploy Infrastructure

```bash
cd cloudformation

aws cloudformation create-stack \
    --stack-name threat-detection-system \
    --template-body file://cloudformation_threat_detection.yaml \
    --parameters ParameterKey=NotificationEmail,ParameterValue=your-email@company.com \
    --capabilities CAPABILITY_NAMED_IAM \
    --region us-east-1

# Wait for completion (3-5 minutes)
aws cloudformation wait stack-create-complete \
    --stack-name threat-detection-system
```

### Step 4: Deploy Lambda Function

```bash
cd ../lambda

# Package Lambda
zip threat_detection_lambda.zip threat_detection_lambda.py

# Upload
aws lambda update-function-code \
    --function-name threat-detection-handler \
    --zip-file fileb://threat_detection_lambda.zip \
    --region us-east-1
```

### Step 5: Configure Streamlit

```bash
cd ../streamlit

# Install dependencies
pip install -r requirements.txt

# Create secrets directory
mkdir -p .streamlit

# Create secrets.toml (replace with your values)
cat > .streamlit/secrets.toml <<EOF
[aws]
region = "us-east-1"
threats_table = "security-threats"
sns_topic_arn = "YOUR_SNS_TOPIC_ARN"
EOF
```

### Step 6: Update Your Streamlit App

In your main `streamlit_app.py`, update the import:

```python
# OLD (Demo version)
# from ai_threat_scene_6_complete import render_ai_threat_analysis_scene

# NEW (Production version)
from ai_threat_scene_6_PRODUCTION import render_ai_threat_analysis_scene
```

### Step 7: Test the System

```bash
cd ../scripts
./test.sh
```

This will:
- Create a test IAM policy change
- Verify Lambda detection
- Check DynamoDB storage
- Confirm SNS alerts

---

## 🧪 Testing & Verification

### Manual Test

Create a test threat:

```bash
aws iam put-role-policy \
    --role-name YourTestRole \
    --policy-name TestPolicy \
    --policy-document '{
        "Version": "2012-10-17",
        "Statement": [{
            "Effect": "Allow",
            "Action": "s3:*",
            "Resource": "*"
        }]
    }'
```

### View Results

**1. Check Lambda Logs:**
```bash
aws logs tail /aws/lambda/threat-detection-handler --follow
```

**2. Query DynamoDB:**
```bash
aws dynamodb scan --table-name security-threats --max-items 5
```

**3. View in Streamlit:**
```bash
cd streamlit
streamlit run your_app.py
```
Navigate to: **AI-Powered Remediation → Threat Analysis**

---

## 🔧 Configuration

### Environment Variables (Lambda)

Edit in AWS Console or CloudFormation:

| Variable | Purpose | Default |
|----------|---------|---------|
| `THREATS_TABLE` | DynamoDB table name | `security-threats` |
| `SNS_TOPIC_ARN` | Alert destination | From CloudFormation |

### Detection Rules (EventBridge)

Current patterns detected:
- ✅ IAM policy changes
- ✅ S3 bucket policy changes
- ✅ CloudTrail tampering

**Add more patterns:**
Edit `cloudformation/cloudformation_threat_detection.yaml` and add EventBridge rules.

### Severity Thresholds (Lambda)

Edit `lambda/threat_detection_lambda.py`:

```python
# Line ~50: High-risk actions
high_risk_actions = [
    'PutRolePolicy',
    'CreateAccessKey',
    # Add more...
]
```

---

## 📊 Monitoring

### CloudWatch Dashboard

```bash
aws cloudwatch put-dashboard \
    --dashboard-name ThreatDetection \
    --dashboard-body file://docs/dashboard.json
```

### Key Metrics

- **Lambda Invocations** - Should match CloudTrail volume
- **Lambda Errors** - Should be near zero
- **DynamoDB Operations** - Track costs
- **SNS Deliveries** - Verify alerts sent

### Set Up Alarms

```bash
aws cloudwatch put-metric-alarm \
    --alarm-name threat-detection-errors \
    --metric-name Errors \
    --namespace AWS/Lambda \
    --statistic Sum \
    --period 300 \
    --evaluation-periods 1 \
    --threshold 5 \
    --comparison-operator GreaterThanThreshold \
    --dimensions Name=FunctionName,Value=threat-detection-handler
```

---

## 💰 Cost Estimation

### Monthly Costs (Approximate)

| Service | Usage | Cost |
|---------|-------|------|
| CloudTrail | 1M events | $2.00 |
| Lambda | 100K invocations | $0.20 |
| DynamoDB | On-demand | $1.25 |
| Bedrock (Claude) | 1K requests | $6.00 |
| SNS | 100 notifications | $0.05 |
| EventBridge | 100K events | $1.00 |
| **Total** | | **~$10.50/month** |

**Scales with event volume.** Monitor with AWS Cost Explorer.

---

## 🐛 Troubleshooting

### No threats detected?

**Check:**
1. CloudTrail is logging:
   ```bash
   aws cloudtrail get-trail-status --name security-monitoring-trail
   ```

2. EventBridge rules enabled:
   ```bash
   aws events list-rules
   ```

3. Lambda has permissions:
   ```bash
   aws lambda get-function --function-name threat-detection-handler
   ```

4. Lambda logs for errors:
   ```bash
   aws logs tail /aws/lambda/threat-detection-handler --follow
   ```

### Lambda timeouts?

Increase timeout and memory:
```bash
aws lambda update-function-configuration \
    --function-name threat-detection-handler \
    --timeout 120 \
    --memory-size 1024
```

### Bedrock errors?

Verify model access:
```bash
aws bedrock list-foundation-models \
    --region us-east-1 \
    --query 'modelSummaries[?modelId==`anthropic.claude-3-5-sonnet-20241022-v2:0`]'
```

### Streamlit can't connect?

Test AWS connectivity:
```bash
python3 -c "import boto3; print(boto3.client('dynamodb').describe_table(TableName='security-threats'))"
```

---

## 🔄 Maintenance

### Weekly
- ✅ Review threat logs
- ✅ Check false positive rate
- ✅ Update threat indicators

### Monthly
- ✅ Review costs
- ✅ Analyze patterns
- ✅ Update Lambda code
- ✅ Tune EventBridge rules

### Quarterly
- ✅ Review security policies
- ✅ Audit IAM permissions
- ✅ Test disaster recovery

---

## 🔐 Security Best Practices

### 1. Use IAM Roles (Not Access Keys)

For Streamlit on EC2/ECS:
```python
# boto3 automatically uses IAM role
dynamodb = boto3.resource('dynamodb')
```

### 2. Enable Encryption

All services have encryption enabled by default:
- ✅ DynamoDB at rest
- ✅ Lambda environment variables
- ✅ SNS with KMS
- ✅ CloudTrail logs

### 3. Least Privilege

Lambda role only has permissions for:
- Read IAM metadata
- Write to DynamoDB
- Invoke Bedrock
- Publish to SNS

### 4. Log Validation

CloudTrail log validation is enabled to detect tampering.

---

## 📚 Documentation

- **[Production Deployment Guide](docs/PRODUCTION_DEPLOYMENT_GUIDE.md)** - Comprehensive guide
- **[Architecture Diagram](docs/ARCHITECTURE_DIAGRAM.md)** - System architecture
- **[AWS CloudTrail Docs](https://docs.aws.amazon.com/cloudtrail/)** - Event logging
- **[AWS Bedrock Docs](https://docs.aws.amazon.com/bedrock/)** - Claude AI

---

## 🆘 Support & Debugging

### View Logs

```bash
# Lambda execution logs
aws logs tail /aws/lambda/threat-detection-handler --follow

# CloudTrail events
aws cloudtrail lookup-events --max-results 10

# EventBridge rules
aws events list-rules --name-prefix detect-
```

### Test Components

```bash
# Test Lambda manually
aws lambda invoke \
    --function-name threat-detection-handler \
    --payload '{"detail":{"eventName":"PutRolePolicy"}}' \
    response.json

# Query DynamoDB
aws dynamodb query \
    --table-name security-threats \
    --index-name status-timestamp-index \
    --key-condition-expression "#st = :status" \
    --expression-attribute-names '{"#st":"status"}' \
    --expression-attribute-values '{":status":{"S":"ACTIVE"}}'
```

---

## 🔄 Rollback/Cleanup

To remove everything:

```bash
./scripts/rollback.sh
```

This will:
- Delete CloudFormation stack
- Remove Lambda function
- Delete DynamoDB table
- Remove SNS topic
- Optionally delete CloudTrail

---

## 🎯 Success Checklist

Before going live:

- [ ] CloudTrail is logging
- [ ] EventBridge rules triggering
- [ ] Lambda can invoke Bedrock
- [ ] Threats stored in DynamoDB
- [ ] SNS alerts received
- [ ] Streamlit connects to DynamoDB
- [ ] IAM roles have least privilege
- [ ] Encryption enabled
- [ ] Cost monitoring configured
- [ ] CloudWatch alarms set
- [ ] Team trained

---

## 📈 What's Next?

### Phase 1 (Weeks 1-2): Monitor & Tune
- Watch for false positives
- Adjust severity thresholds
- Add custom detection rules

### Phase 2 (Weeks 3-4): Expand Coverage
- Add EC2 security group monitoring
- Add RDS configuration monitoring
- Add VPC flow log analysis

### Phase 3 (Month 2): Automation
- Enable auto-remediation for low-risk threats
- Add Jira/ServiceNow integration
- Create custom compliance frameworks

### Phase 4 (Month 3+): Advanced Features
- Machine learning for anomaly detection
- Behavioral analysis
- Threat intelligence integration

---

## 🎉 You're Ready!

Your production threat detection system is now deployed and operational.

**Key Features:**
- ✅ Real-time threat detection (<5 seconds)
- ✅ AI-powered analysis with Claude
- ✅ Automated remediation capabilities
- ✅ Compliance framework mapping
- ✅ Email + dashboard alerts
- ✅ Complete audit trail

**Monitor your first threats:**
1. Make an IAM policy change
2. Check email for alert (within 1 minute)
3. View in Streamlit dashboard
4. Execute automated remediation

---

## 📞 Need Help?

1. **Check logs:** CloudWatch Logs → /aws/lambda/threat-detection-handler
2. **Review docs:** docs/ folder
3. **Test system:** ./scripts/test.sh
4. **Verify permissions:** IAM Policy Simulator

---

**Last Updated:** November 2024  
**Version:** 1.0.0  
**Author:** Cloud Compliance Canvas Team
